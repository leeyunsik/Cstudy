package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class AddActivity extends AppCompatActivity {

    EditText edtName,edtTextA;
    Button btnAdd;

    Memo res;
    ArrayList<Memo> restList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_activity);
        setTitle("메모 추가");

        edtName = findViewById(R.id.edtName);
        edtTextA = findViewById(R.id.edtTextA);
        btnAdd = findViewById(R.id.btnAdd);

        Intent i =getIntent();
        restList = (ArrayList<Memo>)i.getSerializableExtra("restList");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= edtName.getText().toString();
                String text= edtTextA.getText().toString();
                res=new Memo(name, text);
                restList.add(res);
                try{
                    FileOutputStream fos = openFileOutput("memo2.obj",MODE_PRIVATE);
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    for(int i=0;i<restList.size();i++){
                        oos.writeObject(restList.get(i));
                    }
                    Toast.makeText(getApplicationContext(),"성공적으로 입력하였습니다",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),"입력을 실패했습니다",Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });

    }
}
