package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {

    TextView txtName;
    Button btnSave,btnDelete;
    EditText edtTextD;
    Memo res;

    int a;
    ArrayList<Memo> restList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);
        setTitle("나의 메모장 보기");

        txtName = findViewById(R.id.txtName);
        btnSave= findViewById(R.id.btnSave);
        btnDelete= findViewById(R.id.btnDelete);
        edtTextD = findViewById(R.id.edtTextD);


        Intent i = getIntent();
        res=(Memo)i.getSerializableExtra("restInfo");
        txtName.setText(res.getSubject());
        edtTextD.setText(res.getMemo());
        a=i.getIntExtra("intt",0);
        restList = (ArrayList<Memo>)i.getSerializableExtra("restList");
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name= txtName.getText().toString();
                String text= edtTextD.getText().toString();
                res=new Memo(name, text);
                restList.set(a,res);
                try{
                    FileOutputStream fos = openFileOutput("memo2.obj",MODE_PRIVATE);
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    for(int i=0;i<restList.size();i++){
                        oos.writeObject(restList.get(i));
                    }
                    Toast.makeText(getApplicationContext(),"성공적으로 입력하였습니다",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),"입력을 실패했습니다",Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                restList.remove(a);
                try{
                    FileOutputStream fos = openFileOutput("memo2.obj",MODE_PRIVATE);
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    for(int i=0;i<restList.size();i++){
                        oos.writeObject(restList.get(i));
                    }
                    Toast.makeText(getApplicationContext(),"성공적으로 삭제하였습니다",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),"삭제를 실패했습니다",Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });

    }
}
