package com.example.project;

import java.io.Serializable;

public class Memo  implements Serializable {
    private String subject; private String memo;
    public Memo(String subject, String memo) {
        this.subject = subject;this.memo = memo; }
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }
    public String getMemo() {
        return memo; }
    public void setMemo(String memo) {
        this.memo = memo;
    }}
