package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    Button btnAdd;

    ArrayList<String> restData;
    ArrayList<Memo> restList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("메모장");

        listView = findViewById(R.id.listView);
        btnAdd =findViewById(R.id.btnAdd);

        restData = new ArrayList<String>();
        restList =new ArrayList<Memo>();

        adapter = new   ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,restData);
        listView.setAdapter(adapter);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this,AddActivity.class);
                in.putExtra("restList",restList);
                startActivity(in);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent in = new Intent(MainActivity.this,DetailActivity.class);
                Memo res = restList.get(i);
                in.putExtra("restInfo",res);
                in.putExtra("restList",restList);
                in.putExtra("intt",i);
                startActivity(in);
            }
        });

    }
    void loadItem(){
        try {
            FileInputStream inFs = openFileInput("memo2.obj");
            ObjectInputStream ois = new ObjectInputStream(inFs);

            while(restList.add((Memo) ois.readObject())){};
        }catch (Exception e){

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        restData.clear();
        restList.clear();
        loadItem();

        for(int i=0;i<restList.size();i++){
            restData.add(restList.get(i).getSubject());
        }
        adapter.notifyDataSetChanged();
    }
}
