package spring;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

//자동 주입과 함께 사용하는 기능, 스프링이 직접 클래스를 검색해서 bean으로 등록해 주는 기능
	 //appCtx.java에 bean으로 등록하지 않아도 원하는 클래스를 bean으로 등록, 설정코드가 줄어드는 장점 pom.xml의 spring-framework-version을 수정해야함 5.2.0
@Component
public class MemberDao {

	 
	private static long nextId = 0;
	private Map<String,Member> map = new HashMap<>();
			
	public Member selectByEmail(String email) {
		return map.get(email);
	}
	public void insert(Member member) {
		member.setId(++nextId);
		map.put(member.getEmail(), member);
	}
	public void update(Member member) {
		map.put(member.getEmail(),member);
	}
	public Collection<Member> selectAll(){
		return map.values();
	}
}
