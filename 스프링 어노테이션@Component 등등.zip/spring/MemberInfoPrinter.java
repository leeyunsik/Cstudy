package spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("infoPrinter")
public class MemberInfoPrinter {
	//@Autowired 이거 쓸때 오류나는데 펏번째는 일치하는 bean이 없을때 2번재는 자동주입을 적용한 대상에 일치하는 bean이 2개 이상일 경우
	private MemberDao memberDao;
	//@Autowired
	private MemberPrinter printer;
	
	public void printMemberInfor(String email) {
		Member member = memberDao.selectByEmail(email);
		if(member == null) {
			System.out.println("데이터 없음");
			return;
		}
		printer.print(member);
		System.out.println();
	}
	@Autowired
	public void setMemberDao(MemberDao memberDao) {
		this.memberDao = memberDao;
	}
	@Autowired
	@Qualifier("printer")
	public void setPrinter(MemberPrinter printer) {
		this.printer = printer;
	}
	
	
}
