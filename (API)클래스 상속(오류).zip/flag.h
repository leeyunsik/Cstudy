#pragma once

//Scene Type

enum SCENE_TYPE
{
	ST_INGAME
};

