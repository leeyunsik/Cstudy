#include "..\SceneManager.h"
#include "inGameScene.h"



DEFINITION_SINGLE(CSceneManager)

CSceneManager::CSceneManager():
	m2_pScene(NULL)
{
	
}


CSceneManager::~CSceneManager()
{SAFE_DELETE(m2_pScene);
}

bool CSceneManager::Init()
{

	return true;
}
