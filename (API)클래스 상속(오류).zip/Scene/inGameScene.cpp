#include "inGameScene.h"



CinGameScene::CinGameScene()
{
}


CinGameScene::~CinGameScene()
{
}
