#include "..\Scene.h"



CScene::CScene() 

{
	
}


CScene::~CScene()
{


}
