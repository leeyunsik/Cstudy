#pragma once


typedef struct _tagResolution
{
	unsigned int iW;
	unsigned int iH;
}RESOLUTION , *PRESOLUTION;