#include "..\SceneManager.h"

DEFINITION_SINGLE(CSceneManager)

CSceneManager::CSceneManager()
{
}


CSceneManager::~CSceneManager()
{
}

bool CSceneManager::Init()
{

	return true;
}
