package com.example.midexam;

public class Call {
    String call;

    Call(String call){
        this.call=call;
    }
    public void setCall(String call){
        this.call=call;
    }
    public String getCall(String call){
        return call;
    }
}
