package com.example.midexam;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView mList;
    Button btncall;
    ArrayList<Call> mArray;
    Call mItem;
    CallAdapter mAdapter;
    File file;
    ArrayList<String> items;
    String[] call={"01099323381","01090123381"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mList = findViewById(R.id.listView);
        btncall = findViewById(R.id.btncall);
        items = new ArrayList<String>();

        file = new File(getFilesDir(),"tel");
        loadItem();
        mArray = new ArrayList<Call>();
        for(int i=0;i<call.length;i++){
            mItem = new Call(call[i]);
            mArray.add(mItem);

            mAdapter = new CallAdapter(this,mArray);
            mList.setAdapter(mAdapter);

        }

        btncall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ina= new Intent(getApplicationContext(),SubActivity.class);
                startActivity(ina);
            }
        });

    }
    void loadItem(){
        FileReader fr;
        BufferedReader bufrd;
        String str;
        if(file.exists()){
            try{
                fr = new FileReader(file);
                bufrd = new BufferedReader(fr);
                while ((str=bufrd.readLine())!=null){
                    items.add(str);
                }

                bufrd.close();
                fr.close();
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

