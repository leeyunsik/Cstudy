package com.example.midexam;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

public class SubActivity extends AppCompatActivity {

    EditText editcall;
    Button btncall2;
    ArrayList<String> items;
    File file;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sub);

        editcall= findViewById(R.id.edtcall);
        btncall2 =findViewById(R.id.btncall2);
        file = new File(getFilesDir(),"tel");
        btncall2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = editcall.getText().toString();
                if(str.length()>0){
                    items.add(str);
                    saveItem();
                    editcall.setText("");


                }
            }
        });

    }
    void saveItem(){
        FileWriter fw;
        BufferedWriter bufwr;
        try{
            fw = new FileWriter(file);
            bufwr = new BufferedWriter(fw);

            for(String str:items){
                bufwr.write(str);
                bufwr.newLine();
            }
            bufwr.flush();
            bufwr.newLine();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
