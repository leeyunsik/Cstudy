package com.example.midexam;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;


public class CallAdapter extends BaseAdapter {
    Context mContext;
    ArrayList<Call> mData;

    public CallAdapter(Context mContext, ArrayList<Call> mData){
        this.mContext = mContext;
        this.mData = mData;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }
    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {

        if(view == null){
            view=View.inflate(mContext, R.layout.item,null);
        }


        TextView txtcall = view.findViewById(R.id.txtcall);
        ImageView imgcall = view.findViewById(R.id.imgcall);
        txtcall.setText(mData.get(i).call);


        final int position=i;
        imgcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = "tel:"+mData.get(position).call;
                Uri uri = Uri.parse(a);
                Intent in = new Intent((Intent.ACTION_DIAL),uri);
                mContext.startActivity(in);
            }
        });





        return view;
    }
}
